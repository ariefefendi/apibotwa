
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?=$setting->app_name;?></title>
    <!-- plugins:css -->
    <link rel="stylesheet"  href="<?= base_url("assets/purple/assets/vendors/mdi/css/materialdesignicons.min.css")?>">
    <link rel="stylesheet"  href="<?= base_url("assets/purple/assets/vendors/css/vendor.bundle.base.css")?>">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet"  href="<?= base_url("assets/purple/assets/css/style.css")?>">
    <!-- End layout styles -->
    <link rel="shortcut icon"  href="<?= base_url("assets/purple/assets/images/favicon.png")?>" />
  </head>
  <body>
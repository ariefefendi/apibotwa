<?php

class Devices extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('whatsva');
        header("Content-Type: application/json");
        $this->load->model('messages_model');
        $this->load->model('setting_model');
        $this->load->model('device_model');
        $this->load->model('auth_model');
        $this->load->model('transaksi_model');
    }
    public function getQR($device)
    {
		$datasetting = $this->setting_model->getSetting();
        $data_device = $this->device_model->getbyId($device);


        $data['current_user'] = $this->auth_model->current_user();
        $data['transaksi']= $this->transaksi_model->getWhere2(["id_user" => $data['current_user']->id,"status_paid"=>"3"]);
		$active_day = 0;
		
		foreach ($data['transaksi'] as $a => $value) {
			# code...
			$active_day += $value->day_value;
			
		}
		 $start_date = substr($data['current_user']->start_date,0,10);
		
		 $data['active_day'] = $active_day;
		
		$date	= date_create( $start_date);
		$d 		= date_add($date,date_interval_create_from_date_string($active_day." days"));
		$end_date = date_format($date,"d-M-Y");
		$data['end_date'] = $end_date;
		$data['start_date'] = date_format(date_create($start_date),"d-M-Y");
		 $a = new DateTime(date('d-M-Y'));
		 $b = new DateTime($end_date);
		
		 $remaining = $b->diff($a)->days; 
        if($remaining < 1){
            echo json_encode(["success"=>false,"message"=>"Pay your bill, to use this feature"]);
        }else{
            if ($data_device) {
                $data = $this->whatsva->statusInstance($data_device->api_key,$datasetting->panel_key);
                $data = json_decode($data);
           
                if($data){
                    if ($data->success) {
                        if ($data->data->status === "authenticated") {
                            $updateStatus = $this->device_model->update(["status" => 2], $data_device->id);
                        }
                        
                        echo json_encode(["success"=>"true","data"=>["qr"=>$data_device->qr_code]]);
        
                    }
                }else{
                    echo json_encode(["success"=>false,"message"=>"cant connect to server"]);
                }
              
    
            }
        }


     
    }
    public function updateMultidevice()
    {
         // Takes raw data from the request
       
         $instance_key = $this->input->post('instance_key');
          $multidevice = $this->input->post('multidevice');
         
    
            if ($instance_key == "") {
                $response = ["success" => false, "message" => "instance_key empty"];
            } else if($multidevice == ""){
                $response = ["success" => false, "message" => "multidevice empty"];
            }else{
               
                $datasetting = $this->setting_model->getSetting();
            
                $data_device = $this->device_model->getWhere(["api_key"=>$instance_key]);
              
                if ($data_device) {
                    $update = $this->whatsva->updateMultideviceInstance($instance_key,$datasetting->panel_key,$multidevice);
                    $update = json_decode($update);
                    if($update){
                     
                        if($update->success){
                            $updateStatus = $this->device_model->update(["multidevice" => $multidevice], $data_device->id);
                           
                        }
                        echo json_encode($update);
                    }else{
                        echo json_encode(["success"=>false,"message"=>"cant connect to server"]);
                    }
                }
               
            }
       
        # code...
       
      
    }
}
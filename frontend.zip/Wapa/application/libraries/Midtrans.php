<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
require_once('./midtrans-php/Midtrans.php');

class Midtrans{

	public function __construct()
	{
		parent::__construct();
	}
}

?>